# Paired Callback Lab console fix

This update gives the Sender and Listener their own Guacamole common-JS terminal client. The previous paired panes loaded two full Guacamole web clients at the same browser origin; their shared browser authentication state caused the Listener to show the Sender connection or a Guacamole login screen. The update uses the existing Academy authenticated WebSocket proxy and one scoped console grant per VM. It does not add a tunnel or change the isolated lab network.

It also clears Ubuntu 26.04 OSC 3008 shell metadata for the `learner` account in new Callback VMs. This keeps Guacamole from printing `machineid`, `hostname`, `bootid`, and `type` metadata into the terminal. Existing running VMs need no reset; the production session hosts were already updated.

## Install

1. Copy and extract this package on the Academy services VM.
2. From the extracted folder, run `sudo bash scripts/install-paired-console-fix.sh`.
3. The installer checks the source hashes and accepted prior versions, backs up the current API and worker code, installs the paired terminal page, restarts only the API and worker, and checks API health.
4. In the Academy, open the existing Callback Lab session and select Reconnect for Sender and Listener.
5. Confirm Sender shows `academy-<session>-sender` and Listener shows `academy-<session>-listener`. Run `hostname` in each pane. Confirm the terminal accepts input and the IPs differ.
6. Start an exercise and confirm both terminals remain usable. Check Hint and Solution, then confirm Netlab still opens its normal terminal.

Do not reset or end a learner session to install this change. If health checks fail, the installer restores the source files from the printed backup directory and restarts the API and worker.

## Release scope

This is a focused update for an existing Academy that already has the Callback Lab. It is not a full offline installation image. The included files can also be inspected and verified with `sha256sum -c SHA256SUMS.txt` before installation.