# Class slide viewer update

This focused update presents one slide at a time inside each class module. Learners can use Previous/Next, enter a page number, use arrow keys after focusing the viewer, or open the viewer full screen. The original PDF remains available in a separate tab.

PDF.js 5.6.205 and its required CMaps and standard fonts are included for offline operation. Slides stay on a white page in both light and dark themes. No external CDN or internet access is required.

## Install

1. Copy `Academy_Class_Slide_Viewer_20261022.tar.gz` and its `.sha256` sidecar to the Academy services VM.
2. Check the archive with `sha256sum -c Academy_Class_Slide_Viewer_20261022.tar.gz.sha256`.
3. Extract it to a temporary directory, then run `sha256sum -c SHA256SUMS.txt` inside the extracted directory.
4. Run `sudo bash scripts/install-class-slide-viewer.sh` from that directory. The installer checks the expected production revision, backs up the two replaced files, installs all viewer assets, and switches `index.html` last. It does not restart services or change the database, users, grades, or lab sessions.
5. Reload a Linux, Networking, and Security module. Check the first slide, Next, Previous, page-number jump, full screen, and the separate-PDF link.

The installer stops if production files do not match the reviewed baseline. In that case, preserve the package and update the expected version only after reviewing the live difference.

## Rollback

The installer records its backup under `/root/academy-backups/*-class-slide-viewer`. Restore the saved `index.html` and `learning.js`, then remove `frontend/slide-viewer.js`, `frontend/slide-viewer.css`, and `frontend/vendor/pdfjs`. No process restart is required.

This is an incremental update for the existing Training Academy deployment. It is not a complete fresh-install image.
