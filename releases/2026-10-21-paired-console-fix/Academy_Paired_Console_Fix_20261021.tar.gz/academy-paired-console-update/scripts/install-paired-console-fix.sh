#!/usr/bin/env bash
set -euo pipefail
umask 077
bundle="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
root=/opt/uscc-academy
cd "$root"
test "$(id -u)" -eq 0 || { echo 'Run as root.' >&2; exit 1; }
test -f compose.yaml && test -f academy/app.py && test -f academy/worker.py
cd "$bundle"
sha256sum -c SHA256SUMS.txt
cd "$root"
stamp="$(date -u +%Y%m%dT%H%M%SZ)"
backup="/root/academy-backups/${stamp}-paired-console-fix"
work="$(mktemp -d)"
mkdir -m 700 -p "$backup/academy" "$backup/frontend"
trap 'rm -rf "$work"' EXIT
cp "$bundle/academy/app.py" "$bundle/academy/worker.py" "$bundle/frontend/guac-terminal.html" "$bundle/frontend/guac-terminal.js" "$bundle/frontend/guac-terminal.css" "$work/"
old_app=26a18ef7a8394445a32d6909aa756b8178cb04439d663c901868bda4a1529e76
old_worker=4d2e1d6c9d3bf07b438bd23300c412772ed6d26d714cca773b4f148246843fc5
new_app=e00cdc15cbbd635ea34a8c06a8978f1a4e4cb28e5c14a17b43d3b4d02ea149bc
new_worker=0fe327e23c8be3b053bb0bd713841bb035fe50179b715698979334a6a3993602
current_app="$(sha256sum academy/app.py | cut -d ' ' -f1)"
current_worker="$(sha256sum academy/worker.py | cut -d ' ' -f1)"
[[ "$current_app" == "$old_app" || "$current_app" == "$new_app" ]] || { echo 'Unexpected app.py version; no changes made.' >&2; exit 1; }
[[ "$current_worker" == "$old_worker" || "$current_worker" == "$new_worker" ]] || { echo 'Unexpected worker.py version; no changes made.' >&2; exit 1; }
cp -p academy/app.py academy/worker.py "$backup/academy/"
for file in guac-terminal.html guac-terminal.js guac-terminal.css; do
  if [[ -e "frontend/$file" ]]; then cp -p "frontend/$file" "$backup/frontend/"; else touch "$backup/frontend/$file.absent"; fi
done
(cd "$backup" && find academy frontend -type f -print0 | sort -z | xargs -0 sha256sum > SHA256SUMS.txt)
restore() {
  trap - ERR
  cp -p "$backup/academy/app.py" "$backup/academy/worker.py" academy/
  for file in guac-terminal.html guac-terminal.js guac-terminal.css; do
    if [[ -e "$backup/frontend/$file.absent" ]]; then rm -f "frontend/$file"; elif [[ -e "$backup/frontend/$file" ]]; then cp -p "$backup/frontend/$file" frontend/; fi
  done
  docker compose restart api worker >/dev/null || true
  echo "Update rolled back from $backup" >&2
}
trap restore ERR
python3 -m py_compile "$work/app.py" "$work/worker.py"
install -m 0644 "$work/app.py" academy/app.py
install -m 0644 "$work/worker.py" academy/worker.py
install -m 0644 "$work/guac-terminal.html" frontend/guac-terminal.html
install -m 0644 "$work/guac-terminal.js" frontend/guac-terminal.js
install -m 0644 "$work/guac-terminal.css" frontend/guac-terminal.css
docker compose restart api worker >/dev/null
for _ in $(seq 1 40); do
  if docker compose exec -T api python -c 'import urllib.request; urllib.request.urlopen("http://127.0.0.1:8000/api/health", timeout=3)' >/dev/null 2>&1; then
    docker compose exec -T api python -c 'import academy.app, academy.worker'
    trap - ERR
    echo "PAIRED_CONSOLE_FIX_INSTALLED backup=$backup"
    exit 0
  fi
  sleep 2
done
echo 'API health check failed after update.' >&2
exit 1