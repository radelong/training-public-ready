#!/usr/bin/env bash
set -Eeuo pipefail

root=/opt/uscc-academy
pkg_dir=$(cd -- "$(dirname -- "$0")/.." && pwd)
base_index=02c6208ffb72853ba5deb8a711890038c792ccb4ebe0043cc4aaf40c15776907
base_learning=721b5c9184eb58e732d75d42f81d120e406c33c7c2a8b82c1c7b4e0f9db442ea

die() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }
[[ $EUID -eq 0 ]] || die 'Run as root.'
[[ -d "$root/frontend" ]] || die "Academy frontend not found at $root/frontend"
(cd "$pkg_dir" && sha256sum -c SHA256SUMS.txt) || die 'Package checksum verification failed.'

current_index=$(sha256sum "$root/frontend/index.html" | awk '{print $1}')
current_learning=$(sha256sum "$root/frontend/learning.js" | awk '{print $1}')
target_index=$(awk '$2 == "frontend/index.html" {print $1}' "$pkg_dir/PAYLOAD-SHA256SUMS.txt")
target_learning=$(awk '$2 == "frontend/learning.js" {print $1}' "$pkg_dir/PAYLOAD-SHA256SUMS.txt")
if [[ $current_index == "$target_index" && $current_learning == "$target_learning" ]]; then
  (cd "$root" && sha256sum -c "$pkg_dir/PAYLOAD-SHA256SUMS.txt") || die 'Installed viewer assets do not match this package.'
  echo 'Class slide viewer already matches this package.'
  exit 0
fi
[[ $current_index == "$base_index" ]] || die "Unexpected index.html revision: $current_index"
[[ $current_learning == "$base_learning" ]] || die "Unexpected learning.js revision: $current_learning"
for path in "$root/frontend/slide-viewer.js" "$root/frontend/slide-viewer.css" "$root/frontend/vendor/pdfjs"; do
  [[ ! -e $path ]] || die "Refusing to overwrite existing viewer asset: $path"
done

backup="/root/academy-backups/$(date -u +%Y%m%dT%H%M%SZ)-class-slide-viewer"
install -d -m 0700 "$backup"
cp -a "$root/frontend/index.html" "$backup/index.html"
cp -a "$root/frontend/learning.js" "$backup/learning.js"
printf 'New viewer assets were absent before this update.\n' > "$backup/PREVIOUS_STATE.txt"
rollback() {
  status=$?
  trap - EXIT
  if (( status != 0 )); then
    install -m 0644 "$backup/index.html" "$root/frontend/index.html"
    install -m 0644 "$backup/learning.js" "$root/frontend/learning.js"
    rm -f "$root/frontend/slide-viewer.js" "$root/frontend/slide-viewer.css"
    rm -rf "$root/frontend/vendor/pdfjs"
    echo "Install failed; restored original files from $backup" >&2
  fi
  exit "$status"
}
trap rollback EXIT

install -m 0644 "$pkg_dir/frontend/slide-viewer.js" "$root/frontend/slide-viewer.js"
install -m 0644 "$pkg_dir/frontend/slide-viewer.css" "$root/frontend/slide-viewer.css"
install -d -m 0755 "$root/frontend/vendor"
cp -a "$pkg_dir/frontend/vendor/pdfjs" "$root/frontend/vendor/"
install -m 0644 "$pkg_dir/frontend/learning.js" "$root/frontend/learning.js"
# Switch entry point last, after every referenced asset is present.
install -m 0644 "$pkg_dir/frontend/index.html" "$root/frontend/index.html"
(cd "$root" && sha256sum -c "$pkg_dir/PAYLOAD-SHA256SUMS.txt") || die 'Installed payload verification failed.'
trap - EXIT
echo "CLASS_SLIDE_VIEWER_INSTALLED backup=$backup"
